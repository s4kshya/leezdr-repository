Public Class Form1

    Public WithEvents WebBrowser1 As New WebBrowser
    Public needLogin As Boolean
    Public needRedirect As Boolean
    Public completed As Boolean

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Part 1: Use WebBrowser control to load web page
        needLogin = True
        needRedirect = True
        completed = False
        WebBrowser1 = New WebBrowser
        WebBrowser1.Navigate("http://ads.m1.com.sg/NASApp/AdsContext/AdsLogin.jsp")
    End Sub

    Private Sub WebBrowser1_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted

        ' Part 2: Automatically input username and password
        If completed Then
            WebBrowser1 = Nothing
            Exit Sub

        ElseIf (needLogin) Then
            Dim userid As HtmlElement = WebBrowser1.Document.GetElementById("msisdn")
            Dim password As HtmlElement = WebBrowser1.Document.GetElementById("password")
            Dim submit As HtmlElement = WebBrowser1.Document.GetElementById("Login")
            userid.SetAttribute("Value", "97979974")
            password.SetAttribute("Value", "password")
            submit.InvokeMember("click")
            needLogin = False

        ElseIf (needRedirect) Then
            needRedirect = False
            WebBrowser1.Navigate("http://msgctr.m1.com.sg/MessageCentre/jsp/main/index.jsp")

        Else

            Dim receipient As HtmlElement = WebBrowser1.Document.GetElementById("pno")
            Dim msg As HtmlElement = WebBrowser1.Document.GetElementById("msg")

            receipient.SetAttribute("Value", "97979974")
            msg.SetAttribute("Value", "Cool Man")


            Dim imgLst As HtmlElementCollection = WebBrowser1.Document.GetElementsByTagName("img")
            For Each ele As HtmlElement In imgLst
                If (ele.GetAttribute("src").IndexOf("/MessageCentre/images/btn_send.jpg") > -1) Then
                    completed = True
                    ele.Parent.InvokeMember("click")
                End If

            Next


        End If








    End Sub

End Class
